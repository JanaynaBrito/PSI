<?php
session_start();
header("Location: exec/Dashboard/index.php");
?>