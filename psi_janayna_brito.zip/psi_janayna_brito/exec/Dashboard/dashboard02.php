<?php
require_once "../conn/config_bd.php";
require_once 'dao/uf_remuneracao.php';

// BUSCA DADOS REMUNERAÇÃO POR UF 
$sql_UF = lst_uf_remuneracao();
$sql_UF_results = pg_prepare($conexao, "lst_uf_remuneracao", $sql_UF);
$sql_UF_results = pg_query($conexao, $sql_UF) or die("Cannot execute query: $sql_UF\n");

?>
<head>
 

 
    <html>

    <style>

        #container {
            height: 900px;
            min-width: 310px;
            max-width: 1000px;
            margin: 0 auto;
        }

        .loading {
            margin-top: 10em;
            text-align: center;
            color: gray;
        }


    </style>
</head>
<body>

    <div id="container"></div>
    
    <!-- <div class="card-header"> -->
    <div align="center" class="card-body">	
        <div class="tabela_aviso table-striped" style="padding-top : 20px;">
            <table id="tabelaUF" class="table table-bordered table-striped table-hover compact" cellspacing="0" style="font-size: 1em;">
                <thead>
                    <tr style="background-color: #023666; color: #FFF;">
                        <th>UF</th>
                        <th>QTDE. TRABALHADORES</th>
                        <th>MÉDIA SALARIAL</th>
                        <th>MAIOR SALÁRIO</th>
                        <th>MENOR SALÁRIO</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr style="background-color: #023666; color: #FFF;">
                        <th>UF</th>
                        <th>QTDE. TRABALHADORES</th>
                        <th>MÉDIA SALARIAL</th>
                        <th>MAIOR SALÁRIO</th>
                        <th>MENOR SALÁRIO</th>
                    </tr>
                </tfoot>
                <tbody>
                <?php 
                    $arr = pg_fetch_all($sql_UF_results);
                    $count_arr = count($arr);
                    for ($i = 0; $i < $count_arr; $i++ ): ?>                   
                    <tr>
                        <td>
                            
                                <?php echo ($arr[$i]["uf"]);?>
                            
                        </td>
                        <!-- QTDE. TRABALHADORES -->
                        <td>
                            
                                <?php echo ($arr[$i]["total_trab_uf"]);?>
                            
                        </td>
                        <!-- MÉDIA SALARIAL -->
                        <td>
                            
                                <?php echo ($arr[$i]["med_sal_trab_uf"])?>
                            
                        </td>
                        <!-- MAIOR SALÁRIO -->
                        <td>
                        <?php echo ($arr[$i]["maior_sal_trab_uf"]); ?>
                            
                        </td>
                        <!-- MENOR SALÁRIO -->
                        <td>
                        <?php echo ($arr[$i]["menor_sal_trab_uf"]);?>
                            
                        </td>
                    </tr>
                    <?php endfor; ?>
                </tbody>
                
            </table>
        </div>
    </div>
    <!-- <div class="card-body"> -->

</body>
</html>

<script src="js/dashboard.js"></script>
	
