<?php
require_once "../conn/config_bd.php";
require_once 'dao/uf_remuneracao.php';

// BUSCA DADOS 
$sql_ESC = lst_ESC_qtde_trab();
$sql_ESC_results = pg_prepare($conexao, "lst_ESC_qtde_trab", $sql_ESC);
$sql_ESC_results = pg_query($conexao, $sql_ESC) or die("Cannot execute query: $sql_ESC\n");

// Select alimentando uma váriavel
$arr_ESC_qtde_trab = array();
$arr_ESC_qtde_trab = pg_fetch_all($sql_ESC_results);

$arr_escolaridades = array();

$count_arr = count($arr_ESC_qtde_trab);
for ($i = 0; $i < $count_arr; $i++ ):
    $arr_escolaridades[] = $arr_ESC_qtde_trab[$i]["escolaridade"];
endfor;
$count_arr = null;


// Criando array para armazenar dados da correlação escolariadade e quantidade de trabalhadores
$arr_qtde_trab = array();

$count_arr = count($arr_ESC_qtde_trab);
for ($i = 0; $i < $count_arr; $i++ ):
    $arr_qtde_trab[$arr_ESC_qtde_trab[$i]["escolaridade"]] = $arr_ESC_qtde_trab[$i]["qtde_trab"];
    
endfor;
$count_arr = null;

// aqui irá ser colocado a váriavel que foi alimentada por array no For acima
// para deixar no padrão que o highcharts reconhece
 foreach($arr_qtde_trab as $key => $value)
 {
     $series[] = array('name' => utf8_encode($key), 'data' => intval($value));
 }   



// Criando array para armazenar dados da correlação escolariadade e média salarial
$arr_med_sal = array();

$count_arr = count($arr_ESC_qtde_trab);
for ($i = 0; $i < $count_arr; $i++ ):
    $arr_med_sal[$arr_ESC_qtde_trab[$i]["escolaridade"]] = $arr_ESC_qtde_trab[$i]["med_sal_trab"];
    
endfor;
$count_arr = null;

// aqui irá ser colocado a váriavel que foi alimentada por array no For acima
// para deixar no padrão que o highcharts reconhece
 foreach($arr_med_sal as $key => $value)
 {
    $valor =  'R$' . number_format(floatval($value), 2, ',', '.');
     $series1[] = array('name' => utf8_encode($key), 'data' => round(floatval($value),2));
 }   


?>
<head>
    <html>

    <style>

        #container1 {
            height: 500px;
            /* min-width: 310px;
            max-width: 1000px; */
            margin: 0 auto;
        }

        .loading {
            margin-top: 10em;
            text-align: center;
            color: gray;
        }

        .highcharts-figure,
        .highcharts-data-table table {
            min-width: 310px;
            max-width: 800px;
            margin: 1em auto;
        }

        #container {
            height: 400px;
        }

        .highcharts-data-table table {
            font-family: Verdana, sans-serif;
            border-collapse: collapse;
            border: 1px solid #ebebeb;
            margin: 10px auto;
            text-align: center;
            width: 100%;
            max-width: 500px;
        }

        .highcharts-data-table caption {
            padding: 1em 0;
            font-size: 1.2em;
            color: #555;
        }

        .highcharts-data-table th {
            font-weight: 600;
            padding: 0.5em;
        }

        .highcharts-data-table td,
        .highcharts-data-table th,
        .highcharts-data-table caption {
            padding: 0.5em;
        }

        .highcharts-data-table thead tr,
        .highcharts-data-table tr:nth-child(even) {
            background: #f8f8f8;
        }

        .highcharts-data-table tr:hover {
            background: #f1f7ff;
        }


    </style>
</head>
<body>

<figure class="highcharts-figure">
    <div id="container1"></div>
</figure>


</body>
</html>

<script>
        //Adicionar ao gráfico a correlação entre escolaridade e total de trabalhadores
        var graph_data = <?php echo json_encode($series);?>;
        var graph_keys = [], graph_values = [];
        var graph_values = [];
        for (var i in graph_data) {
            graph_keys.push(graph_data[i].name);
            graph_values.push(graph_data[i].data);
        }
        

        //Adicionar ao gráfico a correlação entre escolaridade e média salarial
        var graph_data1 = <?php echo json_encode($series1);?>;
        var graph_keys1 = [], graph_values1 = [];
        var graph_keys1 = Object.keys(graph_data1);
        var graph_values1 = [];
        for (var i in graph_data1) {
            graph_values1.push(graph_data1[i].data);
        }
        

        //Inicializando o gráfico
		Highcharts.chart('container1', {
            chart: {
                zoomType: 'xy'
            },
            title: {
                text: 'Quantidade de Trabalhadores e Media Salarial por Escolaridade',
                align: 'left'
            },
            xAxis: [{
                categories: <?php echo json_encode($arr_escolaridades);?>,
                crosshair: true
            }],
            yAxis: [{ // Primary yAxis
                labels: {
                    format: 'R$ {value}',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                },
                title: {
                    text: 'Média Salarial',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                }
            }, { // Secondary yAxis
                title: {
                    text: 'Qtde Trabalhadores',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                },
                labels: {
                    format: '{value}',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                },
                opposite: true
            }],
            tooltip: {
                shared: true
            },
            legend: {
                align: 'center',
                x: 70,
                verticalAlign: 'top',
                y: 60,
                floating: true,
                backgroundColor:
                    Highcharts.defaultOptions.legend.backgroundColor || // theme
                    'rgba(255,255,255,0.25)'
            },            
             series: [{
                 name: 'Qtde Trabalhadores',
                 type: 'column',
                 yAxis: 1,
                 data: graph_values
            }, {
                name: 'Média Salarial',
                type: 'spline',
                data: graph_values1
            }]
        });

</script>
