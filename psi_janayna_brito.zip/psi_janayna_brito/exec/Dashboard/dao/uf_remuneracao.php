<?php

function lst_uf_remuneracao() {

    $sql = " select 
                uf, 
                count(idade) as total_trab_uf, 
                cast(avg(COALESCE(remuneracao, 0)) as money) as med_sal_trab_uf, 
                cast(max(COALESCE(remuneracao, 0)) as money) as maior_sal_trab_uf, 
                cast(min(COALESCE(remuneracao, 0)) as money) as menor_sal_trab_uf
            from tb_trabalhadores
            group by uf
            ";

    return $sql;
}

function lst_ESC_qtde_trab() {

    $sql = " select 
                tb_esc.no_escolaridade as escolaridade, 
                count(tb_trab.idade) as Qtde_Trab, 
                avg(COALESCE(tb_trab.remuneracao, 0)) as med_sal_trab
             from tb_trabalhadores as tb_trab
            inner join tb_escolaridade as tb_esc
            on tb_trab.escolaridade = tb_esc.cod_escolaridade
            group by tb_esc.no_escolaridade
            ";

    return $sql;
}