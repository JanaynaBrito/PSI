$(document).ready( function() {
    $(".show-tooltip").tooltip();
    var currentdate = new Date();
    var datetime = currentdate.getDate() + "/"
                + (currentdate.getMonth()+1)  + "/"
                + currentdate.getFullYear() + "  " 
                + currentdate.getHours() + ":" 
                + currentdate.getMinutes() + ":"
                + currentdate.getSeconds() + " @ ";
    
    $.fn.DataTable.ext.pager.numbers_length = 4;
    
    var table = $('#tabelaUF').DataTable({
    
        language: {
            buttons: {
                colvis: 'Colunas visíveis',
                colvisRestore: 'Desfazer seleção',
                copy: 'Copiar',
                pageLength: {
                '_': "<b>Exibindo &nbsp %d &nbsp  Linhas</b>",
                '-1': "<b>Exibindo todas as linhas</b>"
                }
            },
            decimal:        ",",
            emptyTable:     "Nenhum registro disponível na tabela",
            info:           "Exibindo de _START_ a _END_ de _TOTAL_ registros",
            thousands:      ".",
            infoEmpty:      "Não há registros para visualização",
            loadingRecords: "Carregando...",
            processing:     "Processando...",
            search:         "<i class=\"fas fa-search\" aria-hidden=\"true\"></i>",
            searchPlaceholder: "Digite para pesquisar...",
            sInfoFiltered: "(<i class=\"fas fa-search\" > Filtrado a partir do total de _MAX_ registros</i>)",
            zeroRecords:    "Nenhum registro encontrado",
            paginate: {
                first:      "Primeiro",
                last:       "Último",
                next:       ">>",
                previous:   "<<"
            },
            aria: {
                sortAscending:  ": ordenação de coluna crescente ativada",
                sortDescending: ": ordenação de coluna decrescente ativada"
            },
            select: {
                rows: {
                    _: "<p><b> %d linhas selecionadas </b></p>",
                    0: "<p> <b>Utilize o <i>clique simple do mouse</i> para selecionar as linhas desejadas</b> </p>",
                    1: "<p><b> 1 linhas selecionada <b></p>"
                }
            },
            searchBuilder: {
                add: "Adicionar Condição",
                button: {
                    "0": "Construtor de Pesquisa",
                    "_": "Construtor de Pesquisa (%d)"
                },
                clearAll: "Limpar Tudo",
                condition: "Condição",
                conditions: {
                    date: {
                        after: "Depois",
                        before: "Antes",
                        between: "Entre",
                        empty: "Vazio",
                        equals: "Igual",
                        not: "Não",
                        notBetween: "Não Entre",
                        notEmpty: "Não Vazio"
                    },
                    number: {
                        between: "Entre",
                        empty: "Vazio",
                        equals: "Igual",
                        gt: "Maior Que",
                        gte: "Maior ou Igual a",
                        lt: "Menor Que",
                        lte: "Menor ou Igual a",
                        not: "Não",
                        notBetween: "Não Entre",
                        notEmpty: "Não Vazio"
                    },
                    string: {
                        contains: "Contém",
                        empty: "Vazio",
                        endsWith: "Termina Com",
                        notEndsWith: "Não termina Com",
                        equals: "Igual",
                        not: "Não",
                        notEmpty: "Não Vazio",
                        startsWith: "Começa Com",
                        notStartsWith: "Não começa Com",
                        notContains: "Não contém",
                        notStarts: "Não começa com",
                        notEnds: "Não termina com"
                    },
                    array: {
                        contains: "Contém",
                        empty: "Vazio",
                        equals: "Igual à",
                        not: "Não",
                        notEmpty: "Não vazio",
                        without: "Não possui"
                    }
                },
                data: "Colunas",
                deleteTitle: "Excluir regra de filtragem",
                logicAnd: "E",
                logicOr: "Ou",
                title: {
                    "0": "Construtor de Pesquisa",
                    "_": "Construtor de Pesquisa (%d)"
                },
                value: "Valor",
                leftTitle: "Critérios Externos",
                rightTitle: "Critérios Internos"
            },
            searchPanes: {
                clearMessage: "Limpar Tudo",
                collapse: {
                    "0": "Painéis de Pesquisa",
                    "_": "Painéis de Pesquisa (%d)"
                },
                count: "{total}",
                countFiltered: "{shown} ({total})",
                emptyPanes: "Nenhum Painel de Pesquisa",
                loadMessage: "Carregando Painéis de Pesquisa...",
                title: "Filtros Ativos: %d",
                showMessage: "Mostrar todos",
                collapseMessage: "Fechar todos"
            },
            datetime: {
                previous: "Anterior",
                next: "Próximo",
                hours: "Hora",
                minutes: "Minuto",
                seconds: "Segundo",
                amPm: [
                    "am",
                    "pm"
                ],
                unknown: "-",
                months: {
                    "0": "Janeiro",
                    "1": "Fevereiro",
                    "10": "Novembro",
                    "11": "Dezembro",
                    "2": "Março",
                    "3": "Abril",
                    "4": "Maio",
                    "5": "Junho",
                    "6": "Julho",
                    "7": "Agosto",
                    "8": "Setembro",
                    "9": "Outubro"
                },
                weekdays: [
                    "Domingo",
                    "Segunda-feira",
                    "Terça-feira",
                    "Quarta-feira",
                    "Quinte-feira",
                    "Sexta-feira",
                    "Sábado"
                ]
            }
        },
        dom: 'PQfBrtpi',
        searchPanes:{
            initCollapsed: true,
            cascadePanes: true,
            viewTotal: true
        },
        columnDefs: [
                // {
                // 	"targets": [0,5,8],
                // 	"visible": false
                // },
                {
                    searchPanes: {
                        show: true
                    },
                    targets: [0]
                },
                {
                    searchPanes: {
                        show: true
                    },
                    // type: "html-num",
                    targets: [1]
                },
                {
                    searchPanes: {
                        show: true
                    },
                    // type: "html-num",
                    targets: [2]
                },
                {
                    searchPanes: {
                        show: true
                    },
                    // type: "html-num",
                    targets: [3]
                },
                {
                    searchPanes: {
                        show: true
                    },
                    targets: [4]
                }
            ],					
            // "order": [
            // 	[2, 'desc']
            // ],
        displayLength: 5,
        bAutoWidth: false,					
        responsive: true, 
        lengthChange: false,
        lengthMenu: [
            [5, 10, 25, 50, -1],
            ['5', '10', '25', '50', 'Mostrar tudo']
        ],
        buttons: [
            'pageLength',
            {
                extend: 'copy',
                text: '<i class="fas fa-copy fa-1x" aria-hidden="true"> Copiar <b><u>(C)</u></b></i>',
                key: {
                    key: 'c',
                    altKey: true
                },
                exportOptions: {
                    columns: ':visible'
                }
            },
            { 
                extend: 'pdf', 
                messageTop: 'Lista de Qtde. Trabalhadores por UF',
                title: '',
                orientation: 'landscape',
                exportOptions: {
                    columns: ':visible'
                },
                customize: function (doc) {
                    
                    doc.pageMargins = [10,80,20,10];
                    doc.defaultStyle.fontSize = 7;
                    doc.styles.tableHeader.fontSize = 7;
                    doc.styles.title.fontSize = 9;
                    doc.styles.message = {
                        color: 'red',
                        bold: 1, //0 para negrito desativado
                        fontSize: '14',
                        alignment: 'center'
                    };
                    // Remove spaces around page title
                    // doc.content[0].text = doc.content[0].text.trim();
                    // Create a footer
                    doc['footer']=(function(page, pages) {
                        return {
                            columns: [
                                // Abaixo está o que aparecerá no rodapé à esquerda
                                datetime
                                ,
                                {
                                    // Abaixo está o que aparecerá no rodapé à direita
                                    alignment: 'right',
                                    text: [ { text: page.toString() },  ' de ', { text: pages.toString() }]
                                }
                            ],
                            margin: [10, 0]
                        }
                    });
                    
                },
                text: '<i class="fas fa-file-pdf fa-1x" aria-hidden="true"> Exportar a PDF <b><u>(P)</u></b></i>',
                key: {
                    key: 'p',
                    altKey: true
                }
            },
            { 
                extend: 'csv', 
                text: '<i class="fas fa-file-csv fa-1x"> Exportar a CSV <b><u>(V)</u></b></i>',
                key: {
                    key: 'v',
                    altKey: true
                },
                exportOptions: {
                    columns: ':visible'
                }
            },
            { 
                extend: 'excel', 
                text: '<i class="fas fa-file-excel" aria-hidden="true"> Exportar a EXCEL <b><u>(X)</u></b></i>',
                key: {
                    key: 'x',
                    altKey: true
                },
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'collection', className: 'btn exportButton' ,
                text: '<i class="fas fa-print" aria-hidden="true"> Imprimir </i>',
                buttons: [
                    {
                        extend: 'print',
                        customize: function (win) {
                            $(win.document.body)
                                .css('margin-top', '200px')
                                .css('font-size','14px')
                                .prepend('<div style="position:absolute; top:160; right: 30%; text-align: center; font-size: 25px; color: red; font-weight: bold;">Lista de Qtde. Trabalhadores por UF</div>');
            
                            $(win.document.body).find('table')
                                .addClass('compact')
                                .css('margin-top', 'inherit')
                                .css('font-size','inherit') ;
                            
                        },
                        title: '',
                        // message: '&nbsp&nbsp&nbsp',
                        text: '<i class="fas fa-print" aria-hidden="true"> Imprimir - Vertical<b><u>(I)</u></b></i>',
                        key: {
                            key: 'i',
                            altKey: true
                        },
                        exportOptions: {
                            columns: ':visible',
                            modifier: {
                                selected: null,
                            }
                        }
                    },
                    {
                        extend: 'print',
                        customize: function (win) {
                            $(win.document.body)
                                .css('margin-top', '200px')
                                .prepend('<div style="position:absolute; top:160; right: 30%; text-align: center; font-size: 25; color: red; font-weight: bold;">Lista de Qtde. Trabalhadores por UF</div>');
            
                            $(win.document.body).find('table')
                                .addClass('compact')
                                .css('margin-top', 'inherit');
                                // .css('background','inherit') ;
                            
                            $(win.document.body).find( 'th' )
                                .css( 'color', 'white' )
                                .css( 'background', '#023666' )
                                .css( 'font-size', 'inherit');

                            var last = null;
                            var current = null;
                            var bod = [];
            
                            var css = '@page { size: landscape; }',
                                head = win.document.head || win.document.getElementsByTagName('head')[0],
                                style = win.document.createElement('style');
            
                            style.type = 'text/css';
                            style.media = 'print';
            
                            if (style.styleSheet)
                            {
                            style.styleSheet.cssText = css;
                            }
                            else
                            {
                            style.appendChild(win.document.createTextNode(css));
                            }
            
                            head.appendChild(style);	
                        },
                        title: '',
                        // message: '&nbsp&nbsp&nbsp',
                        text: '<i class="fas fa-print" aria-hidden="true"> Imprimir - Horizontal<b><u>(H)</u></b></i>',
                        key: {
                            key: 'h',
                            altKey: true
                        },
                        exportOptions: {
                            columns: ':visible',
                            modifier: {
                                selected: null,
                            }
                        }
                    },
                    {
                        extend: 'print',
                        customize: function (win) {
                            $(win.document.body)
                                .css('margin-top', '200px')
                                .css('font-size','14px')
                                .prepend('<div style="position:absolute; top:160; right: 30%; text-align: center; font-size: 14; color: red; font-weight: bold;">Lista de Qtde. Trabalhadores por UF</div>');
            
                            $(win.document.body).find('table')
                                .addClass('compact')
                                .css('margin-top', 'inherit')
                                .css('font-size','inherit') ;
                            
                        },
                        title: '',
                        text: '<i class="fas fa-vote-yea" aria-hidden="true"> Imprimir seleção <b><u>(S)</u></b></i>',
                        key: {
                            key: 's',
                            altKey: true
                        },
                        exportOptions: {
                            columns: ':visible'
                        }
                    }
                ]
            }, 
            {
                extend: 'colvis',
                text: '<i class="fas fa-columns" aria-hidden="true"> Colunas visíveis</i>',
                postfixButtons: [ 'colvisRestore' ]
            }
        ], 
        select: {
            style: 'multi'
        },
        select: true,
        initComplete: function () {
            this.api().columns().every( function () {
                var column = this;
                var title = column.header();
                //replace spaces with dashes
                title = $(title).html();
                // console.log(title);

                
                

                
            } );
            
        }
    	
});





$(function() {
    $('.btn-group-fab').on('click', '.btn', function() {
        $('.btn-group-fab').toggleClass('active');
    });

});

(async () => {

    const topology = await fetch(
        'https://code.highcharts.com/mapdata/countries/br/br-all.topo.json'
    ).then(response => response.json());


    const data = [];             
    Highcharts.data({
        table: document.getElementById('tabelaUF'),
        startRow: 1,
        startColumn: 0,
        firstRowAsNames: true,
        complete: function (options) {
            options.series[0].data.forEach(function (p) {
                data.push([
                    'br-' + p[0].toLowerCase(),
                    p[1]
                ]);
                
            });
        }
    });
    // Prepare map data for joining
    topology.objects.default.geometries.forEach(function (g) {
        if (g.properties && g.properties.name) {
            g.properties.ucName = g.properties.name.toUpperCase();
            // console.log(g.properties.ucName);
        }
    });

    
    // Create the chart
    var chart = Highcharts.mapChart('container', {
        chart: {
            map: topology
        },

        title: {
            text: 'Dados dos Trabalhadores'
        },

        subtitle: {
            text: 'Mapa: Brazil'
        },

        mapNavigation: {
            enabled: true,
            buttonOptions: {
                verticalAlign: 'bottom'
            }
        },

        colorAxis: {
            min: 0
        },

        xAxis: {
            labels: {
                enabled: false
            }
        },

        colorAxis: {
            labels: {
                format: '{value}'/100
            }
        },

        series: [{
            mapData: topology,
            data,
            name: 'Quantidade de Trabalhadores',
            states: {
                hover: {
                    color: '#a4edba'
                }
            },
            dataLabels: {
                enabled: true,
                format: '{point.name}',
                style: {
                    fontSize: '13px'
                }
            }
        }]
    });
    
    // Quando atualizar a tabela, por exemplo, realizar uma pesquisa(filtro), o gráfico irá refletir automaticamente o filtro realizado na tabela.
    table.on('draw', function () {
        Highcharts.data({
            table: document.getElementById('tabelaUF'),
            startRow: 1,
            startColumn: 0,
            firstRowAsNames: true,
            complete: function (options) {
                data.length = 0;
                options.series[0].data.forEach(function (p) {
                    data.push([
                        'br-' + p[0].toLowerCase(),
                        p[1]
                    ]);
                    
                });
            }
        });

    // Create the chart
    var chart = Highcharts.mapChart('container', {
        chart: {
            map: topology
        },

        title: {
            text: 'Dados dos Trabalhadores'
        },

        subtitle: {
            text: 'Mapa: Brazil'
        },

        mapNavigation: {
            enabled: true,
            buttonOptions: {
                verticalAlign: 'bottom'
            }
        },

        colorAxis: {
            min: 0
        },

        xAxis: {
            labels: {
                enabled: false
            }
        },

        colorAxis: {
            labels: {
                format: '{value}'/100
            }
        },

        series: [{
            mapData: topology,
            data,
            name: 'Quantidade de Trabalhadores',
            states: {
                hover: {
                    color: '#a4edba'
                }
            },
            dataLabels: {
                enabled: true,
                format: '{point.name}',
                style: {
                    fontSize: '13px'
                }
            }
        }]
    });
        
    });
    
    


    })();

        

});



