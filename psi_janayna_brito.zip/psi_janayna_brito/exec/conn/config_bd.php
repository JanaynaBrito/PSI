<?php
$conn_string = "host=localhost dbname=PSI user=postgres password=afb1981";
$dbconn = pg_connect($conn_string);
if (!$conexao = $dbconn) {
// if (!$conexao = OCILogon($user,$senha,$banco)) {
	echo "Erro na conexão com o PostgreSQL.";
	pg_close($conexao);
}


?>
